//
//  ViewController.swift
//  recipeApp
//
//  Created by iD Student on 7/12/16.
//  Copyright © 2016 iD Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mealTypeLabel: UILabel!
   
    @IBOutlet weak var breakfastButton: UIButton!
    @IBOutlet weak var lunchDinnerButton: UIButton!
    @IBOutlet weak var dessertButton: UIButton!
    @IBOutlet weak var snackButton: UIButton!
    
    var buttons = [UIButton]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttons = [breakfastButton, lunchDinnerButton, dessertButton,
            snackButton]
        for button in buttons {
            let layer = CALayer()
            layer.frame = CGRectMake(0, 0, button.bounds.width + 10, button.bounds.height)
            layer.borderWidth = 2
            layer.borderColor = UIColor.lightGrayColor().CGColor
            layer.cornerRadius = 10
            button.layer.addSublayer(layer)
        }
        
    
    
    }

  


}

